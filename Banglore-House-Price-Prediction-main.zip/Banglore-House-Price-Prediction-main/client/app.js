function getBathValue() {
    var uiBathrooms = document.getElementsByName("uiBathrooms");
    for (var i in uiBathrooms) {
        if (uiBathrooms[i].checked) {
            return parseInt(i) + 1;
        }
    }
    return -1; // Invalid Value
}

function getBHKValue() {
    var uiBHK = document.getElementsByName("uiBHK");
    for (var i in uiBHK) {
        if (uiBHK[i].checked) {
            return parseInt(i) + 1;
        }
    }
    return -1; // Invalid Value
}

function onClickedEstimatePrice() {
    console.log("Estimate price button clicked");
    var sqft = document.getElementById("uiSqft");
    var bhk = getBHKValue();
    var bathrooms = getBathValue();
    var location = document.getElementById("uiLocations");
    var estPrice = document.getElementById("uiEstimatedPrice");

    // The URL for your Flask server's prediction endpoint
    var url = "http://127.0.0.1:5000/predict_house_price";

    // Create the JSON payload to send to the server
    var data = {
        total_sqft: parseFloat(sqft.value),
        bhk: bhk,
        bath: bathrooms,
        location: location.value
    };

    // Use fetch to send a POST request
    fetch(url, {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(function(response) {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    }).then(function(data) {
        console.log("Success:", data);
        // Display the estimated price
        estPrice.innerHTML = "<h2>" + data.estimated_price.toString() + " Lakh</h2>";
    }).catch(function(error) {
        console.error('Error:', error);
        estPrice.innerHTML = "<h2>Error predicting price. Please check console.</h2>";
    });
}

function onPageLoad() {
    console.log("document loaded");
    // The URL for your Flask server's location endpoint
    var url = "http://127.0.0.1:5000/get_location_names";
    
    // Use fetch to get the locations from the server
    fetch(url)
        .then(response => response.json())
        .then(data => {
            console.log("got response for get_location_names request");
            if (data) {
                var locations = data.locations;
                var uiLocations = document.getElementById("uiLocations");
                
                // Clear any existing options using standard JavaScript
                uiLocations.innerHTML = '';
                
                // Add a default disabled option
                var defaultOption = new Option("Choose a Location", "", true, true);
                defaultOption.disabled = true;
                uiLocations.appendChild(defaultOption);

                // Populate the dropdown with new locations
                for (var i in locations) {
                    var opt = new Option(locations[i]);
                    uiLocations.appendChild(opt);
                }
            }
        }).catch(error => console.error('Error fetching locations:', error));
}

// Run the onPageLoad function when the window loads
window.onload = onPageLoad;

