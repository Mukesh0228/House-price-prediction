import json
import pickle
import numpy as np

# Global variables to hold the model and data columns
__locations = None
__data_columns = None
__model = None

def get_estimated_price(location, sqft, bhk, bath):
    """
    Predicts the house price based on location, sqft, bhk, and bath.
    """
    try:
        # Find the index for the location column
        loc_index = __data_columns.index(location.lower())
    except ValueError:
        # If location is not found, set index to -1
        loc_index = -1
    
    # Create a numpy array of zeros with the same length as data columns
    x = np.zeros(len(__data_columns))
    x[0] = sqft
    x[1] = bath
    x[2] = bhk
    
    # If the location was found, set its corresponding index to 1
    if loc_index >= 0:
        x[loc_index] = 1
    
    # Predict the price using the loaded model and round it to 2 decimal places
    return round(__model.predict([x])[0], 2)

def get_location_names():
    """
    Returns the list of available locations.
    """
    return __locations

def load_saved_artifacts():
    """
    Loads saved artifacts: the model pickle file and the column json file.
    """
    print("Loading saved artifacts... start")
    global __data_columns
    global __locations
    global __model
    
    # Load data columns and location names from json
    try:
        with open("./artifacts/columns.json", "r") as f:
            __data_columns = json.load(f)["data_columns"]
            # The first 3 columns are sqft, bath, bhk. Locations start from index 3.
            __locations = __data_columns[3:]
    except FileNotFoundError:
        print("Error: 'columns.json' not found. Make sure the artifacts are in the correct directory.")
        __data_columns = []
        __locations = []

    # Load the trained model from pickle file
    try:
        with open("./artifacts/banglore_house_prices_model.pickle", "rb") as f:
            __model = pickle.load(f)
    except FileNotFoundError:
        print("Error: 'banglore_house_prices_model.pickle' not found. Make sure the model file is in the correct directory.")
        __model = None
        
    print("Loading saved artifacts... done")

if __name__ == "__main__":
    # This block is for testing the utility functions directly
    load_saved_artifacts()
    if __locations:
        print("First 5 locations:", get_location_names()[:5])
        print(get_estimated_price("1st Phase JP Nagar", 1000, 3, 3))
        print(get_estimated_price("1st Phase JP Nagar", 1000, 2, 2))
        print(get_estimated_price("Kalhalli", 1000, 2, 2)) # Test a location that might not exist in the top list
        print(get_estimated_price("Ejipura", 1000, 2, 2)) # Test another location
