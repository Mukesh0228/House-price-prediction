from flask import Flask, request, jsonify
from flask_cors import CORS, cross_origin
import util

app = Flask(__name__)
# Enable CORS for the whole app
CORS(app)

@app.route('/get_location_names', methods=['GET'])
@cross_origin() # Add this decorator for extra safety
def get_location_names():
    """
    Returns a list of all location names.
    """
    response = jsonify({
        'locations': util.get_location_names()
    })
    return response

@app.route('/predict_house_price', methods=['POST'])
@cross_origin() # Explicitly allow cross-origin requests for this route
def predict_house_price():
    """
    Endpoint to predict house price based on input features.
    Expects a JSON post with total_sqft, location, bhk, and bath.
    """
    try:
        data = request.get_json()
        total_sqft = float(data['total_sqft'])
        location = data['location']
        bhk = int(data['bhk'])
        bath = int(data['bath'])
        
        estimated_price = util.get_estimated_price(location, total_sqft, bhk, bath)
        
        response = jsonify({
            'estimated_price': estimated_price
        })
        
    except Exception as e:
        response = jsonify({'error': str(e)}), 400

    return response

if __name__ == "__main__":
    print("Starting Python Flask Server For House Price Prediction . . .")
    util.load_saved_artifacts()
    app.run()

