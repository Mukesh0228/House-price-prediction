# Bangalore House Price Prediction

## Project Overview

This project predicts house prices in Bangalore (Bengaluru), India, using machine learning. The application includes data cleaning and exploratory data analysis (EDA), model training, and a server/client setup to provide predictions via an interface.

## Repository Structure


## Dataset

- **Bengaluru_House_Data.csv**: Contains the raw data on house listings in Bangalore. Typical features include square footage, location, number of bedrooms (BHK), bathrooms, etc.

## Key Components

1. **Data Processing and Model Training**
   - Data cleaning: handling missing/invalid values, transforming features (e.g. parsing total_sqft), removing outliers, handling categorical variables like location.
   - Exploratory Data Analysis to understand distributions, relationships, and variation.
   - Model building: selecting features, choosing and training a regression model (e.g., linear regression or others).  
   - Saving the trained model and other necessary metadata (e.g. feature columns) for use in inference.

2. **Backend Server**
   - Provides API endpoint(s) to accept user inputs (features like location, square footage, BHK, etc.).
   - Loads the trained model and returns price predictions.

3. **Client / Frontend**
   - UI forms for users to input features for prediction.
   - Consumes the backend API and displays the predicted house price.

